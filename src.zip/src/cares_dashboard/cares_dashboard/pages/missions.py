from nicegui import ui
from cares_dashboard.layout import theme_wrapper
import cares_dashboard.state as state
import random

ros_driver = None

@ui.page('/missions')
@theme_wrapper
def missions_page():
    
    with ui.row().classes('w-full h-full gap-0'):
        
        # LEFT PANEL
        with ui.column().classes('w-1/3 h-full bg-slate-800 border-r border-slate-700 p-6 gap-6'):
            ui.label('MISSIONS').classes('text-xl font-bold text-emerald-400')
            
            with ui.column().classes('w-full gap-2'):
                ui.label('Mission Type').classes('text-xs text-slate-400')
                m_type = ui.select(['SEARCH', 'RESCUE', 'SURVEY'], value='SEARCH').classes('w-full bg-slate-900')
                
                ui.label('Priority').classes('text-xs text-slate-400 mt-2')
                m_prio = ui.slider(min=1, max=10, value=5).props('label-always')

                ui.label('Target Coordinates').classes('text-xs text-slate-400 mt-2')
                with ui.row().classes('w-full'):
                    mx = ui.number(label='X', value=0).classes('w-1/2')
                    my = ui.number(label='Y', value=0).classes('w-1/2')

            def submit():
                if ros_driver:
                    ros_driver.dispatch_mission(m_type.value, mx.value, my.value, m_prio.value)
                    ui.notify('Order Transmitted', type='positive')
            
            ui.space()
            ui.button('DISPATCH', on_click=submit).classes('w-full bg-emerald-600 py-4 text-lg font-bold')

        # RIGHT PANEL
        with ui.column().classes('flex-grow h-full bg-slate-900 gap-0'):
            
            # TASK ALLOCATION
            with ui.column().classes('w-full h-1/2 p-6 pb-0'):
                ui.label('TASK ALLOCATION').classes('text-xl font-bold text-slate-500 mb-2')
                
                with ui.card().classes('w-full h-full bg-slate-800 p-0 border border-slate-700'):
                    grid = ui.aggrid({
                        'columnDefs': [
                            {'headerName': 'Task ID', 'field': 'id', 'sortable': True},
                            {'headerName': 'Type', 'field': 'type'},
                            {'headerName': 'Status', 'field': 'status', 'cellStyle': {'color': '#10b981'}},
                            {'headerName': 'Winner', 'field': 'winner'},
                            {'headerName': 'Cost', 'field': 'cost'},
                        ],
                        'rowData': [],
                        'rowSelection': 'single',
                    }).classes('w-full h-full ag-theme-balham-dark') 

            # AUCTION LOG
            with ui.column().classes('w-full h-1/2 p-6 pt-4'):
                ui.label('AUCTION LOG').classes('text-xs font-bold text-slate-500 mb-1')
                with ui.card().classes('w-full h-full bg-black border border-slate-700 p-0'):
                    log_area = ui.scroll_area().classes('w-full h-full p-2 font-mono text-xs text-slate-300')

            def update_data():
                grid.options['rowData'] = [
                    {'id': 'T-1024', 'type': 'SEARCH', 'status': 'ACTIVE', 'winner': 'tb3_0', 'cost': 12.5},
                    {'id': 'T-1025', 'type': 'RESCUE', 'status': 'PENDING', 'winner': '-', 'cost': -1},
                ]
                grid.update()
                
                log_area.clear()
                with log_area:
                    ui.label(f"[12:00:01] Auction started for T-1025").classes('text-blue-400')
                    ui.label(f"[12:00:02] tb3_1 bid 45.2 (Cap Match: 0.8)").classes('ml-2')
                    ui.label(f"[12:00:02] jethexa bid 12.1 (Cap Match: 0.2) -> REJECTED").classes('ml-2 text-red-400')

            ui.timer(2.0, update_data)