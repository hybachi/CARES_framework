import rclpy
from rclpy.node import Node
import cares_dashboard.state as state
import random
import time

class RosBridge(Node):
    def __init__(self):
        super().__init__('dashboard_bridge')
        self.create_timer(1.0, self.simulate_data)

    def simulate_data(self):
        robot_ids = ['tb3_0', 'tb3_1', 'jethexa', 'crazyflie']
        
        # Update Robots
        total_cap = 0
        for rid in robot_ids:
            r = state.get_robot(rid)
            r['type'] = 'UAV' if 'crazy' in rid else 'UGV'
            
            # Simulate walking/flying
            r['pose']['x'] += random.uniform(-0.5, 0.5)
            r['pose']['y'] += random.uniform(-0.5, 0.5)
            r['battery'] = max(0, r['battery'] - 0.05)
            
            # Simulate Capability Fluctuation
            r['caps']['MOBILITY'] = random.uniform(0.7, 1.0)
            r['caps']['SENSING'] = random.uniform(0.6, 1.0)
            r['caps']['NETWORK'] = random.uniform(0.8, 1.0)
            
            # Update History for Charts
            r['history']['mob'].append(r['caps']['MOBILITY'])
            r['history']['sen'].append(r['caps']['SENSING'])
            r['history']['net'].append(r['caps']['NETWORK'])
            for k in r['history']: 
                if len(r['history'][k]) > 20: r['history'][k].pop(0)

            total_cap += (sum(r['caps'].values()) / 3)

        # Update Global Metrics
        state.metrics['active_units'] = len(robot_ids)
        state.metrics['swarm_mean_cap'] = round(total_cap / len(robot_ids), 2)
        state.metrics['network_stability'] = random.randint(85, 100)

        # Simulate Random Events
        if random.random() < 0.05:
            state.log_event(f"Task T-{random.randint(100,999)} completed by {random.choice(robot_ids)}")
            state.metrics['tasks_completed'] += 1
        
        if random.random() < 0.02:
            state.log_event(f"VICTIM FOUND at [{random.randint(0,10)}, {random.randint(0,10)}]")
            state.metrics['victims_found'] += 1

    def dispatch_mission(self, task_type, x, y, prio):
        tid = f"T-{random.randint(1000,9999)}"
        state.log_event(f"Mission Dispatched: {tid} ({task_type})")
        return tid